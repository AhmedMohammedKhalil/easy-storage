<div class="row product-cards">
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-12 col-md-4 col-lg-4 col-xl-3 d-md-block d-none">
            <div class=" productcard12">
                <article>
                    <div class="pro-thumb">

                        <?php if($product->image): ?>
                            <img id="<?php echo e($product->id); ?>" style="height:200px" class="img-fluid" src="<?php echo asset('assets/images/data/products/'.$product->id.'/'.$product->image); ?>" alt="Product-Image">
                        <?php else: ?>
                            <img id="<?php echo e($product->id); ?>" style="height:200px" class="img-fluid" src="<?php echo asset('assets/images/img_option/img-1.jpg'); ?>" alt="Product-Image">
                        <?php endif; ?>
                        <div class="pro-hover-icons">
                            <div class="icons">
                                <button class="btn-secondary btn icon" data-bs-toggle="modal"
                                    data-bs-target="#quickViewModalProduct<?php echo e($product->id); ?>" tabindex="0">
                                    عرض
                                </button>
                            </div>
                        </div>
                    </div>


                    <div class="pro-info">

                        <h3><a href="javascript:void(0)" tabindex="0"><?php echo e($product->name); ?></a></h3>

                        <div class="pro-weight">
                            المخذون : <h4 style="display: inline-block !important"><?php echo e($product->quantity); ?></h4>
                        </div>
                        <div class="pro-price">
                            <ins><?php echo e($product->price); ?> دينار كويتى</ins>
                        </div>

                    </div>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('cashier.add-order', ['p_id' => $product->id])->html();
} elseif ($_instance->childHasBeenRendered('order1_'.$product->id)) {
    $componentId = $_instance->getRenderedChildComponentId('order1_'.$product->id);
    $componentTag = $_instance->getRenderedChildComponentTagName('order1_'.$product->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('order1_'.$product->id);
} else {
    $response = \Livewire\Livewire::mount('cashier.add-order', ['p_id' => $product->id]);
    $html = $response->html();
    $_instance->logRenderedChild('order1_'.$product->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </article>
            </div>
        </div>




        <div class="modal fade" id="quickViewModalProduct<?php echo e($product->id); ?>" tabindex="-1" role="dialog" aria-hidden="true">

            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-body">

                        <div class="container">
                            <div class="row ">
                                <div class="col-12 col-md-6">
                                    <div class="row justify-content-center">
                                        <?php if($product->image): ?>
                                            <img id="<?php echo e($product->id); ?>" style="height:300px;width:unset" class="img-fluid" src="<?php echo asset('assets/images/data/products/'.$product->id.'/'.$product->image); ?>" alt="Product-Image">
                                        <?php else: ?>
                                            <img id="<?php echo e($product->id); ?>" style="height:300px;width:unset" class="img-fluid" src="<?php echo asset('assets/images/img_option/img-1.jpg'); ?>" alt="Product-Image">
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-12 col-md-6 pro-description">
                                    <div class="row">
                                        <div class="col-12 col-md-12">

                                            <h3><?php echo e($product->name); ?></h3>

                                            <div class="pro-price">
                                                <ins><?php echo e($product->price); ?> دينار كويتى</ins>
                                            </div>
                                            <div class="pro-info">
                                                <div class="pro-single-info"><b>كود المنتج :</b><span><?php echo e($product->code); ?></span></div>
                                                <div class="pro-single-info"><b>نوع المنتج :</b><span><?php echo e($product->category->name); ?></span></div>
                                                <div class="pro-single-info"><b>حالة المنتج :</b><span><?php if($product->quantity == 0): ?> غير متاح <?php else: ?> متاح <?php endif; ?></span></div>
                                                <div class="pro-single-info"><b>الكمية المتاحة:</b><span><?php echo e($product->quantity); ?></span></div>
                                                <div class="pro-single-info"><b>الكمية المباعة :</b><span><?php echo e($product->quantity_sold); ?></span></div>
                                                <div class="pro-single-info"><b> وصف المنتج :</b><span><?php echo nl2br($product->details); ?></span></div>

                                            </div>

                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close" style="top:0 !important
                        ">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



</div>
<?php /**PATH D:\xampp\htdocs\easy-storage\resources\views/livewire/cashier/results.blade.php ENDPATH**/ ?>