<?php $__env->startSection('content'); ?>
    <div style="min-height:800px;">
        <?php echo $__env->make('layouts.header',['title' => 'من نحن'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="page-area pro-content" style="padding: 100px 0">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-md-6">
                        <img style="height: 400px;width:100%" src="<?php echo e(asset('assets/images/data/abouts/1/about-us.png')); ?>" alt="profile">
                    </div>
                    <div class="col-12 col-md-6">
                        <div class="heading">
                            <h3>
                                من نحن
                            </h3>
                        </div>
                        <p class="peragraph2">
                            <?php echo nl2br($about->content); ?>

                        </p>
                    </div>
                </div>
                <div class="row justify-content-center account-content" style="padding: 100px 0">
                    <div class="heading">
                        <h3 style="text-align: center;font-weight:500;font-size:1.75rem">
                            تواصل معنا
                        </h3>
                    </div>
                    <div class="col-12 col-sm-12 col-md-6">
                        <div class="col-12  px-0">
                            <div class="tab-content" id="registerTabContent">
                                <div class="tab-pane fade show active" id="login" role="tabpanel"
                                    aria-labelledby="login-tab">
                                    <div class="registration-process">
                                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('about', [])->html();
} elseif ($_instance->childHasBeenRendered('cnMjNmw')) {
    $componentId = $_instance->getRenderedChildComponentId('cnMjNmw');
    $componentTag = $_instance->getRenderedChildComponentTagName('cnMjNmw');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('cnMjNmw');
} else {
    $response = \Livewire\Livewire::mount('about', []);
    $html = $response->html();
    $_instance->logRenderedChild('cnMjNmw', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>


    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\easy-storage\resources\views/abouts.blade.php ENDPATH**/ ?>