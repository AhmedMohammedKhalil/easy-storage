<div class="container-fuild" style="height:230px">
    <div class="page-header" style="padding:100px; background-image: url('<?php echo e(asset('assets/images/data/home/header.png')); ?>')">
        <div class="container">
            <h3 class="page-title text-center" style="color: white"><?php echo e($title); ?></h3>
        </div>
        <!-- End .container -->
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\easy-storage\resources\views/layouts/header.blade.php ENDPATH**/ ?>