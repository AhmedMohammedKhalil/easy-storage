<?php $__env->startSection('content'); ?>
    <div style="min-height:800px;">
        <?php echo $__env->make('layouts.header',['title' => 'تسجيل دخول الكاشير'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="page-area pro-content" style="padding: 100px 0">
        <div class="container">
            <div class="row justify-content-center account-content">
                <div class="col-12 col-sm-12 col-md-6">
                    <div class="col-12  px-0">
                        <div class="tab-content" id="registerTabContent">
                            <div class="tab-pane fade show active" id="login" role="tabpanel"
                                aria-labelledby="login-tab">
                                <div class="registration-process">
                                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('cashier.login', [])->html();
} elseif ($_instance->childHasBeenRendered('hDPK3xY')) {
    $componentId = $_instance->getRenderedChildComponentId('hDPK3xY');
    $componentTag = $_instance->getRenderedChildComponentTagName('hDPK3xY');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('hDPK3xY');
} else {
    $response = \Livewire\Livewire::mount('cashier.login', []);
    $html = $response->html();
    $_instance->logRenderedChild('hDPK3xY', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\easy-storage\resources\views/cashiers/login.blade.php ENDPATH**/ ?>