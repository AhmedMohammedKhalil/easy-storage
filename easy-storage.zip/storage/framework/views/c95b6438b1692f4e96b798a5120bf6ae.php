<?php $__env->startSection('content'); ?>
    <div style="min-height:800px;">
        <?php echo $__env->make('layouts.header',['title' => 'نقطة بيع'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="page-area pro-content" style="padding: 100px 0">
            <div class="container">
                <div class="row justify-content-center account-content">
                    <div class="col-12 col-sm-12 col-md-6">
                        <div class="col-12  px-0">
                            <div class="tab-content" id="registerTabContent">
                                <div class="tab-pane fade show active" id="login" role="tabpanel"
                                    aria-labelledby="login-tab">
                                    <div class="registration-process">
                                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('cashier.search', [])->html();
} elseif ($_instance->childHasBeenRendered('zylCp8c')) {
    $componentId = $_instance->getRenderedChildComponentId('zylCp8c');
    $componentTag = $_instance->getRenderedChildComponentTagName('zylCp8c');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('zylCp8c');
} else {
    $response = \Livewire\Livewire::mount('cashier.search', []);
    $html = $response->html();
    $_instance->logRenderedChild('zylCp8c', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <div class="page-area pro-content" style="padding: 100px 0">
            <div class="container">
                <div class="row">
                    <div class="col-12 px-4">
                        <div class="pro-heading-title">
                            <h2 class="text-center">المنتجات
                            </h2>
                        </div>
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('cashier.result', [])->html();
} elseif ($_instance->childHasBeenRendered('nVQw01t')) {
    $componentId = $_instance->getRenderedChildComponentId('nVQw01t');
    $componentTag = $_instance->getRenderedChildComponentTagName('nVQw01t');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('nVQw01t');
} else {
    $response = \Livewire\Livewire::mount('cashier.result', []);
    $html = $response->html();
    $_instance->logRenderedChild('nVQw01t', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\easy-storage\resources\views/sale.blade.php ENDPATH**/ ?>