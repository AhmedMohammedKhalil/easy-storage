<form wire:submit.prevent='completeOrder'>
    <div class="summery">
        <h3 class="text-center">تسجيل العميل</h3>
        <table class="table right-table">
            <tbody>
                <tr class="d-flex justify-content-between flex-column">
                    <td style="border: unset">
                        <input type="text" class="form-control" id="name"
                            aria-describedby="name" placeholder="ادخل الإسم" wire:model.lazy="name" >
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </td >
                    <td style="border: unset"><input type="text" class="form-control" id="phone"
                            aria-describedby="phone" placeholder="ادخل رقم الهاتف" wire:model.lazy='phone'>
                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </td>
                </tr>
            </tbody>
        </table>
        <button class="btn d-flex btn-secondary justify-content-center w-100">إتمام الطلب</button>
    </div>
</form>
<?php /**PATH D:\xampp\htdocs\easy-storage\resources\views/livewire/cashier/compelete-order.blade.php ENDPATH**/ ?>