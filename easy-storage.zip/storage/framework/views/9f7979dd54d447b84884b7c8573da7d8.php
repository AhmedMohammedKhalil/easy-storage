<?php $__env->startPush('css'); ?>
    <style>
        .cart-area h2{
            font-size: 20px !important;
            margin-bottom: 0;
            padding-top: 10px;
            text-align: center
        }

        .cart-area .right-table tbody th, .cart-area .right-table tbody td {
            padding: 10px 5px;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('header'); ?>
<?php echo $__env->make('layouts.header',['title'=>'جميع الطلبات'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('section'); ?>
        <div class="page-area pro-content pt-0" >
            <div class="container">
                <div class="row justify-content-center account-content">
                    <div class="col-12 col-sm-12 col-md-12">
                        <div class="col-12  px-0">
                            <div class="tab-content" id="registerTabContent">
                                <div class="tab-pane fade show active" id="login" role="tabpanel"
                                    aria-labelledby="login-tab">
                                    <div class="registration-process">
                                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('order.search', [])->html();
} elseif ($_instance->childHasBeenRendered('fixZStu')) {
    $componentId = $_instance->getRenderedChildComponentId('fixZStu');
    $componentTag = $_instance->getRenderedChildComponentTagName('fixZStu');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('fixZStu');
} else {
    $response = \Livewire\Livewire::mount('order.search', []);
    $html = $response->html();
    $_instance->logRenderedChild('fixZStu', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <section style="padding-top: 100px">
            <div class="container">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('order.result')->html();
} elseif ($_instance->childHasBeenRendered('qEWAyd4')) {
    $componentId = $_instance->getRenderedChildComponentId('qEWAyd4');
    $componentTag = $_instance->getRenderedChildComponentTagName('qEWAyd4');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('qEWAyd4');
} else {
    $response = \Livewire\Livewire::mount('order.result');
    $html = $response->html();
    $_instance->logRenderedChild('qEWAyd4', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('cashiers.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\easy-storage\resources\views/cashiers/orders/index.blade.php ENDPATH**/ ?>