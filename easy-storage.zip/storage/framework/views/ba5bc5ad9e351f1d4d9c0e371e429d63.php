<?php $__env->startPush('css'); ?>
    <style>
        .accordian h2{
            margin-bottom: 0
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('header'); ?>
<?php echo $__env->make('layouts.header',['title'=>'إدارة معرض الصور'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('section'); ?>
<section class="order-content">
    <h2 class="text-center" style="font-weight:bold;margin-bottom:30px"> جميع الصور </h2>
    <div class="col-12 col-sm-12 justify-content-center btn-cont">
        <div class="row">
            <a href="<?php echo e(route('admin.gallary.create')); ?>"
                class="btn btn-secondary">إضافة صورة جديدة</a>
        </div>
    </div>
    <?php $__currentLoopData = $gallaries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="accordian" style="margin-top: 20px">
        <table class="table top-table order-table">
            <tbody>
                <tr class="d-flex" style="margin-bottom: 0">
                    <td class="col-12 col-md-8">
                        <?php if($gallary->image): ?>
                            <img style="height:100px" class="img-fluid" src="<?php echo asset('assets/images/data/galleries/'.$gallary->id.'/'.$gallary->image); ?>" alt="image">
                        <?php else: ?>
                            <img style="height:100px" class="img-fluid" src="<?php echo asset('assets/images/img_option/img-1.jpg'); ?>" alt="image">
                        <?php endif; ?>
                    </td>
                    <td class="col-12 col-md-4 justify-content-around">
                        <a href="<?php echo e(route('admin.gallary.edit',['id'=>$gallary->id])); ?>" style="padding:0 10px">
                            <i class="fas fa-pen-alt"></i>
                        </a>
                        <?php if(count($gallaries) > 4): ?>
                        <a href="<?php echo e(route('admin.gallary.delete',['id'=>$gallary->id])); ?>" style="padding:0 10px">
                            <i class="fas fa-trash-alt"></i>
                        </a>
                        <?php endif; ?>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php if(count($gallaries) == 0): ?>
    <div class="col-12 col-sm-12 justify-content-center" style="margin-top: 30px">
        <h3 class="text-center">لا يوجد صور</h3>
    </div>
    <?php endif; ?>

</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\easy-storage\resources\views/admins/gallaries/index.blade.php ENDPATH**/ ?>