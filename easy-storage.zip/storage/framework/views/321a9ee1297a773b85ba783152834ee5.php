<!doctype html>
<html class="Ar" lang="rtl">

<head>
    <meta charset="utf-8">
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="icon" type="image/png" href="images/miscellaneous/fav.png">
    <title><?php echo e(config('app.name', 'Easy Storage')); ?></title>

    <!-- Fontawesome CSS Files -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/fontawesome.min.css')); ?>">

    <!-- Core CSS Files -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/style.css')); ?>">

    <!-- Slider Revolution CSS Files -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/revolution/css/settings.css')); ?> ">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/revolution/css/layers.css')); ?> ">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/revolution/css/navigation.css')); ?> ">

    <style>
        .header-mobile .header-maxi .navigation-mobile-container #navigation-mobile .main-manu {
            text-align: right !important;
        }

        *{
            font-family: "Shamel-Book" !important
        }

        .fa, .far, .fas {
            font-family: "Font Awesome 5 Free" !important;
        }

        .checkout-area .checkoutd-nav .nav-pills .nav-link:hover {
            border: 2px solid;
            border-radius: 3px;
            background-color: transparent;
            color: var(--secondary);
        }

        .nav-link:hover{
            color:  var(--secondary) !important
        }

        .tp-parallax-wrap, .tp-loop-wrap, .tp-mask-wrap {
            position: relative !important;
        }

        .tp-bgimg{
            height: 800px !important;
        }

        .tp-parallax-wrap{
            left: 0 !important;
            top: 80px !important;
            margin: auto;
            width: fit-content;
            text-align: center
        }

        .tp-caption {
            width: fit-content !important;
            min-width: unset !important;
            text-align: center !important
        }

        .bodyrtl .rev_slider_wrapper .tp-parallax-wrap {
            direction: rtl;
        }
        .tp-caption.BigBold-Title, .BigBold-Title{
            text-align: center !important
        }
    </style>
    <?php echo \Livewire\Livewire::styles(); ?>

    <?php echo $__env->yieldPushContent('css'); ?>
</head>

<body class="bodyrtl">

    <div class="wrapper" style="display: none;">
        <!-- //header style One-->
        <header id="headerSeven" class="header-area header-seven header-desktop" style="font-weight: bolder">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-12 col-lg-5 d-flex justify-content-start">
                        <nav class="navbar navbar-expand-lg">
                            <div class="navbar-collapse">
                                <ul class="navbar-nav">
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(route('home')); ?>">
                                            الرئيسية
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(route('aboutus')); ?>">
                                            من نحن
                                        </a>
                                    </li>
                                    <?php if(auth()->guard('cashier')->check()): ?>
                                        <li class="nav-item">
                                            <a class="nav-link" href="<?php echo e(route('cashier.sale')); ?>">
                                                نقطة بيع
                                            </a>
                                        </li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </nav>
                    </div>
                    <div class="col-12 col-lg-2">
                        <div class="logo">
                            <a href="<?php echo e(route('home')); ?>">
                                <img style="height: 100px" class="img-fluid" src="<?php echo e(asset('assets/images/data/home/logo.png')); ?>" alt="logo here">
                            </a>
                        </div>
                    </div>
                    <div class="col-12 col-lg-5 d-flex justify-content-end">
                        <?php if (! (auth('admin')->check() || auth('cashier')->check())): ?>
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('cashier.login')); ?>">
                                    تسجيل الدخول
                                </a>
                            </li>
                        </ul>
                        <?php endif; ?>
                        <?php if(auth('admin')->check() || auth('cashier')->check()): ?>
                        <?php if(auth('cashier')->check()): ?>
                            <ul class="navbar-nav" style="margin-left: 10px">
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('cashier.purchases')); ?>">
                                        الفاتورة الحالية
                                    </a>
                                </li>
                            </ul>
                        <?php endif; ?>
                            <ul class="pro-header-right-options">
                                <li class="dropdown profile-tags list-icon">
                                    <button class="btn icon dropdown-toggle" type="button" id="dropdownAccountButton42"
                                        data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <h6 style="margin-bottom: 0;font-size: 0.875rem;font-weight:bolder">
                                            <?php if(auth()->guard('admin')->check()): ?>
                                                <?php echo e(auth('admin')->user()->name); ?>

                                            <?php else: ?>
                                               <?php echo e(auth('cashier')->user()->name); ?>

                                            <?php endif; ?>
                                        </h6>

                                    </button>
                                    <div class="dropdown-menu dropdown-menu-right"
                                        aria-labelledby="dropdownAccountButton42">
                                        <?php if(auth()->guard('admin')->check()): ?>
                                            <a class="dropdown-item" href="<?php echo e(route('admin.dashboard')); ?>">لوحة التحكم</a>
                                            <a class="dropdown-item" href="<?php echo e(route('admin.logout')); ?>">خروج</a>
                                        <?php endif; ?>
                                        <?php if(auth()->guard('cashier')->check()): ?>
                                        <a class="dropdown-item" href="<?php echo e(route('cashier.profile')); ?>">البروفايل</a>
                                        <a class="dropdown-item" href="<?php echo e(route('cashier.logout')); ?>">خروج</a>
                                        <?php endif; ?>
                                    </div>
                                </li>
                            </ul>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </header>

        <!-- //Mobile Header -->
        <header id="headerMobile" class="header-area header-mobile">

            <div class="header-maxi bg-header-bar ">
                <div class="container">

                    <div class="row align-items-center">
                        <div class="col-8 pr-0 flex-col">
                            <div class="navigation-mobile-container">
                                <a href="javascript:void(0)" class="navigation-mobile-toggler">
                                    <span class="fas fa-bars"></span>
                                </a>
                                <nav id="navigation-mobile">
                                    <div class="logout-main">
                                        <div class="welcome">
                                            <?php if (! (auth('admin')->check() || auth('cashier')->check())): ?>
                                                <span>مرحباً</span>
                                            <?php endif; ?>
                                            <?php if(auth()->guard('cashier')->check()): ?>
                                                <span>مرحباً <?php echo e(auth('cashier')->user()->name); ?></span>
                                            <?php endif; ?>
                                            <?php if(auth()->guard('admin')->check()): ?>
                                                <span>مرحباً <?php echo e(auth('admin')->user()->name); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <a class="main-manu btn" href="<?php echo e(route('home')); ?>" >
                                        الرئيسية
                                    </a>
                                    <a class="main-manu btn" href="<?php echo e(route('aboutus')); ?>" >
                                        من نحن
                                    </a>

                                    <?php if (! (auth('admin')->check() || auth('cashier')->check())): ?>
                                        <a href="<?php echo e(route('cashier.login')); ?>" class="main-manu btn ">
                                            تسجيل الدخول
                                        </a>
                                    <?php endif; ?>

                                    <?php if(auth()->guard('admin')->check()): ?>
                                        <a href="<?php echo e(route('admin.dashboard')); ?>" class="main-manu btn ">
                                            لوحة التحكم
                                        </a>
                                        <a href="<?php echo e(route('admin.logout')); ?>" class="main-manu btn ">
                                            خروج
                                        </a>
                                    <?php endif; ?>


                                    <?php if(auth()->guard('cashier')->check()): ?>
                                        <a class="main-manu btn" href="<?php echo e(route('cashier.sale')); ?>" >
                                            نقطة بيع
                                        </a>
                                        <a href="<?php echo e(route('cashier.profile')); ?>" class="main-manu btn ">
                                            البروفايل
                                        </a>
                                        <a href="<?php echo e(route('cashier.purchases')); ?>" class="main-manu btn">
                                            مشترياتى
                                        </a>
                                        <a href="<?php echo e(route('cashier.logout')); ?>" class="main-manu btn ">
                                            خروج
                                        </a>
                                    <?php endif; ?>



                                </nav>
                            </div>

                        </div>
                        <div class="col-4 pr-0 flex-col justify-content-end">
                            <a href="<?php echo e(route('home')); ?>" class="logo">
                                <img style="height:50px" class="img-fluid" src="<?php echo e(asset('assets/images/data/home/logo.png')); ?>" alt="logo here">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </header>


        <?php echo $__env->yieldContent('content'); ?>

        <div class="container-fluid copyright-main p-0" style="margin-top: 50px">
            <div class="copyright-content">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-12">
                            <div class="footer-info text-center">
                                ©&nbsp;جميع الحقوق محفوظة لموقع <span dir="ltr">2024 @ <a href="<?php echo e(route('home')); ?>">Easy Storage</a></span>
                            </div>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="mobile-overlay"></div>
    <a href="#" class="btn-secondary " id="back-to-top" title="Back to top">&uarr;</a>
    <div class="notifications" id="notificationCart" style="z-index: 999999">تم إضافة المنتج فى عرية المشتريات</div>












    <script src="<?php echo e(asset('assets/js/scripts.js')); ?>"></script>
    <!-- Slider Revolution core JavaScript files -->
    <script src="<?php echo e(asset('assets/revolution/js/jquery.themepunch.tools.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/revolution/js/jquery.themepunch.revolution.min.js')); ?>"></script>
    <!-- Slider Revolution extension scripts. ONLY NEEDED FOR LOCAL TESTING -->
    <script src="<?php echo e(asset('assets/revolution/js/extensions/revolution.extension.actions.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/revolution/js/extensions/revolution.extension.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/revolution/js/extensions/revolution.extension.kenburn.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/revolution/js/extensions/revolution.extension.layeranimation.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/revolution/js/extensions/revolution.extension.migration.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/revolution/js/extensions/revolution.extension.parallax.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/revolution/js/extensions/revolution.extension.slideanims.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/revolution/js/extensions/revolution.extension.video.min.js')); ?>"></script>
    <?php echo \Livewire\Livewire::scripts(); ?>

    <?php echo $__env->yieldPushContent('js'); ?>
</body>

</html>
<?php /**PATH D:\xampp\htdocs\easy-storage\resources\views/layouts/app.blade.php ENDPATH**/ ?>