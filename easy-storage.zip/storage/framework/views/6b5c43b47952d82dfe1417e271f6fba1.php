<?php $__env->startPush('header'); ?>
<?php echo $__env->make('layouts.header',['title'=>'إضافة فئة جديدة'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('section'); ?>
<section class="order-content">
    <div class="heading-title">
        <h2 class="text-center" style="font-weight:bold;margin-bottom:30px"> إضافة فئة جديدة  </h2>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.category.add')->html();
} elseif ($_instance->childHasBeenRendered('2xbaupW')) {
    $componentId = $_instance->getRenderedChildComponentId('2xbaupW');
    $componentTag = $_instance->getRenderedChildComponentTagName('2xbaupW');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('2xbaupW');
} else {
    $response = \Livewire\Livewire::mount('admin.category.add');
    $html = $response->html();
    $_instance->logRenderedChild('2xbaupW', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\easy-storage\resources\views/admins/categories/create.blade.php ENDPATH**/ ?>