<?php $__env->startSection('content'); ?>
    <div style="min-height:800px">
        <?php echo $__env->yieldPushContent('header'); ?>
        <div class="pro-content checkout-area">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-xl-12">
                        <div class="row">
                            <div class="col-12 col-lg-3 ">
                                <?php echo $__env->make('cashiers.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                            <div class="col-12 col-lg-9 ">
                                <div class="checkout-module">
                                    <div class="tab-content">
                                        <div class="tab-pane fade show active">
                                            <?php echo $__env->yieldContent('section'); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\easy-storage\resources\views/cashiers/layout.blade.php ENDPATH**/ ?>