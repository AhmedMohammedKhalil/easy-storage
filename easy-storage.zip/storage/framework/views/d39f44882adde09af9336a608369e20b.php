<?php $__env->startPush('css'); ?>
    <style>
        .accordian h2{
            margin-bottom: 0
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('header'); ?>
<?php echo $__env->make('layouts.header',['title'=>'إدارة الفئات '], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('section'); ?>
<section class="order-content">
    <h2 class="text-center" style="font-weight:bold;margin-bottom:30px"> جميع الفئات </h2>
    <div class="col-12 col-sm-12 justify-content-center btn-cont">
        <div class="row">
            <a href="<?php echo e(route('admin.category.create')); ?>"
                class="btn btn-secondary">إضافة فئة جديدة</a>
        </div>
    </div>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="accordian" style="margin-top: 20px">
        <table class="table top-table order-table">
            <tbody>
                <tr class="d-flex" style="margin-bottom: 0">
                    <td class="col-12 col-md-8">
                       <h2><?php echo nl2br( $category->name ); ?></h2>
                    </td>
                    <td class="col-12 col-md-4 justify-content-around">
                        <a href="<?php echo e(route('admin.category.edit',['id'=>$category->id])); ?>" style="padding:0 10px">
                            <i class="fas fa-pen-alt"></i>
                        </a>
                        <?php if(count($category->products) == 0): ?>
                        <a href="<?php echo e(route('admin.category.delete',['id'=>$category->id])); ?>" style="padding:0 10px">
                            <i class="fas fa-trash-alt"></i>
                        </a>
                        <?php endif; ?>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php if(count($categories) == 0): ?>
    <div class="col-12 col-sm-12 justify-content-center" style="margin-top: 30px">
        <h3 class="text-center">لا يوجد فئات</h3>
    </div>
    <?php endif; ?>

</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\easy-storage\resources\views/admins/categories/index.blade.php ENDPATH**/ ?>