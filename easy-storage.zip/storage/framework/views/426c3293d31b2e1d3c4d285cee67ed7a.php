<?php $__env->startSection('content'); ?>
    <div style="min-height:800px;">
        <?php echo $__env->make('layouts.header',['title' => 'تسجيل دخول الأدمن'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="page-area pro-content" style="padding: 100px 0">
        <div class="container">


            <div class="row justify-content-center account-content">
                <div class="col-12 col-sm-12 col-md-6">
                    <div class="col-12  px-0">
                        <div class="tab-content" id="registerTabContent">
                            <div class="tab-pane fade show active" id="login" role="tabpanel"
                                aria-labelledby="login-tab">
                                <div class="registration-process">
                                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.login', [])->html();
} elseif ($_instance->childHasBeenRendered('Cq0FntX')) {
    $componentId = $_instance->getRenderedChildComponentId('Cq0FntX');
    $componentTag = $_instance->getRenderedChildComponentTagName('Cq0FntX');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Cq0FntX');
} else {
    $response = \Livewire\Livewire::mount('admin.login', []);
    $html = $response->html();
    $_instance->logRenderedChild('Cq0FntX', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\easy-storage\resources\views/admins/login.blade.php ENDPATH**/ ?>