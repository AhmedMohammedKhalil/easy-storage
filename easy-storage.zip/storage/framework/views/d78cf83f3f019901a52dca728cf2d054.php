<div class="checkoutd-nav">
    <ul class="nav flex-column nav-pills mb-3" id="pills-tab">
        <li class="nav-item">
            <a class="nav-link <?php if(request()->routeIs('admin.dashboard')): ?> active <?php endif; ?>"  href="<?php echo e(route('admin.dashboard')); ?>" >لوحة التحكم</a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php if(request()->routeIs('admin.cashier*')): ?> active <?php endif; ?>"  href="<?php echo e(route('admin.cashier.index')); ?>" >إدارة المسؤلين عن الكاشير</a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php if(request()->routeIs('admin.category*')): ?> active <?php endif; ?>"  href="<?php echo e(route('admin.category.index')); ?>" >إدارة الفئات</a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php if(request()->routeIs('admin.product*')): ?> active <?php endif; ?>"  href="<?php echo e(route('admin.product.index')); ?>" >إدارة المنتجات</a>
        </li>

        <li class="nav-item">
            <a class="nav-link <?php if(request()->routeIs('admin.about*')): ?> active <?php endif; ?>"  href="<?php echo e(route('admin.about.index')); ?>" >إدارة من نحن</a>
        </li>

        <li class="nav-item">
            <a class="nav-link <?php if(request()->routeIs('admin.gallary*')): ?> active <?php endif; ?>"  href="<?php echo e(route('admin.gallary.index')); ?>" >إدارة معرض الصور</a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php if(request()->routeIs('admin.slider*')): ?> active <?php endif; ?>"  href="<?php echo e(route('admin.slider.index')); ?>" >إدارة السلايدرز</a>
        </li>

        <li class="nav-item">
            <a class="nav-link  <?php if(request()->routeIs('admin.contact*')): ?> active <?php endif; ?>"  href="<?php echo e(route('admin.contact.index')); ?>" >جميع الرسائل</a>
        </li>

        <li class="nav-item">
            <a class="nav-link <?php if(request()->routeIs('admin.orders')): ?> active <?php endif; ?>"  href="<?php echo e(route('admin.orders')); ?>" >جميع الطلبات</a>
        </li>

        <li class="nav-item">
            <a class="nav-link <?php if(request()->routeIs('admin.profile')): ?> active <?php endif; ?>" href="<?php echo e(route('admin.profile')); ?>">البروفايل</a>
        </li>

        <li class="nav-item">
            <a class="nav-link <?php if(request()->routeIs('admin.changePassword')): ?> active <?php endif; ?>"  href="<?php echo e(route('admin.changePassword')); ?>">تغيير كلمة السر</a>
        </li>

        <li class="nav-item">
            <a class="nav-link <?php if(request()->routeIs('admin.settings')): ?> active <?php endif; ?>"  href="<?php echo e(route('admin.settings')); ?>">الإعدادات</a>
        </li>

        <li class="nav-item">
            <a class="nav-link <?php if(request()->routeIs('admin.logout')): ?> active <?php endif; ?>"  href="<?php echo e(route('admin.logout')); ?>">خروج</a>
        </li>
    </ul>
</div>
<?php /**PATH D:\xampp\htdocs\easy-storage\resources\views/admins/menu.blade.php ENDPATH**/ ?>