<?php $__env->startPush('header'); ?>
<?php echo $__env->make('layouts.header',['title'=>'البروفايل'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('section'); ?>
<div class="blog_ blog-4">
    <h2 class="text-center" style="font-weight:bold;margin-bottom:30px"> البيانات الشخصية </h2>

    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="blog">
                <div class="blog-thumb">

                    <?php if(auth('cashier')->user()->image): ?>
                            <img style="height: 500px" class="img-fluid" src="<?php echo asset('assets/images/data/cashiers/'.auth('cashier')->user()->id.'/'.auth('cashier')->user()->image); ?>" alt="image">
                        <?php else: ?>
                            <img style="height: 500px" class="img-fluid" src="<?php echo asset('assets/images/img_option/img-1.jpg'); ?>" alt="image">
                    <?php endif; ?>
                </div>
                <div class="blog-info text-black">

                    <h3><a href="javascript:void(0)"><?php echo e(auth('cashier')->user()->name); ?></a></h3>
                    <p class="mb-2"><?php echo e(auth('cashier')->user()->c_number); ?></p>
                    <p class="mb-2"><?php echo e(auth('cashier')->user()->email); ?></p>
                    <p class="mb-2"><?php echo e(auth('cashier')->user()->phone); ?></p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('cashiers.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\easy-storage\resources\views/cashiers/profile.blade.php ENDPATH**/ ?>