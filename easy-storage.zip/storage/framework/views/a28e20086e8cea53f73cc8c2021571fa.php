<?php $__env->startPush('header'); ?>
<?php echo $__env->make('layouts.header',['title'=>'تعديل بيانات الكاشير'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('section'); ?>
<section class="order-content">
    <div class="heading-title">
        <h2 class="text-center" style="font-weight:bold;margin-bottom:30px"> تعديل بيانات كاشير  </h2>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.cashier.edit',['cashier_id'=>$cashier_id])->html();
} elseif ($_instance->childHasBeenRendered('pCYM9UZ')) {
    $componentId = $_instance->getRenderedChildComponentId('pCYM9UZ');
    $componentTag = $_instance->getRenderedChildComponentTagName('pCYM9UZ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('pCYM9UZ');
} else {
    $response = \Livewire\Livewire::mount('admin.cashier.edit',['cashier_id'=>$cashier_id]);
    $html = $response->html();
    $_instance->logRenderedChild('pCYM9UZ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\easy-storage\resources\views/admins/cashiers/edit.blade.php ENDPATH**/ ?>