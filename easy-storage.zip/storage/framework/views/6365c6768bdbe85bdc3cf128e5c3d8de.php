<?php $__env->startPush('css'); ?>
    <style>
        .cart-area h2{
            font-size: 20px !important;
            margin-bottom: 0;
            padding-top: 10px;
            text-align: center
        }

        .cart-area .right-table tbody th, .cart-area .right-table tbody td {
            padding: 10px 5px;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('header'); ?>
<?php echo $__env->make('layouts.header',['title'=>'جميع الطلبات'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('section'); ?>
        <div class="page-area pro-content pt-0" >
            <div class="container">
                <div class="row justify-content-center account-content">
                    <div class="col-12 col-sm-12 col-md-12">
                        <div class="col-12  px-0">
                            <div class="tab-content" id="registerTabContent">
                                <div class="tab-pane fade show active" id="login" role="tabpanel"
                                    aria-labelledby="login-tab">
                                    <div class="registration-process">
                                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('order.search', [])->html();
} elseif ($_instance->childHasBeenRendered('QIow9YH')) {
    $componentId = $_instance->getRenderedChildComponentId('QIow9YH');
    $componentTag = $_instance->getRenderedChildComponentTagName('QIow9YH');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('QIow9YH');
} else {
    $response = \Livewire\Livewire::mount('order.search', []);
    $html = $response->html();
    $_instance->logRenderedChild('QIow9YH', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <section style="padding-top: 100px">
            <div class="container">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('order.result')->html();
} elseif ($_instance->childHasBeenRendered('yn3Mw3F')) {
    $componentId = $_instance->getRenderedChildComponentId('yn3Mw3F');
    $componentTag = $_instance->getRenderedChildComponentTagName('yn3Mw3F');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('yn3Mw3F');
} else {
    $response = \Livewire\Livewire::mount('order.result');
    $html = $response->html();
    $_instance->logRenderedChild('yn3Mw3F', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\easy-storage\resources\views/admins/orders/index.blade.php ENDPATH**/ ?>