<?php $__env->startPush('header'); ?>
<?php echo $__env->make('layouts.header',['title'=>'تعديل البيانات الشخصية'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('section'); ?>
<section class="order-content">
    <div class="heading-title">
        <h2 class="text-center" style="font-weight:bold;margin-bottom:30px"> تغيير البيانات الشخصية  </h2>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('cashier.settings')->html();
} elseif ($_instance->childHasBeenRendered('dLhKxIn')) {
    $componentId = $_instance->getRenderedChildComponentId('dLhKxIn');
    $componentTag = $_instance->getRenderedChildComponentTagName('dLhKxIn');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('dLhKxIn');
} else {
    $response = \Livewire\Livewire::mount('cashier.settings');
    $html = $response->html();
    $_instance->logRenderedChild('dLhKxIn', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('cashiers.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\easy-storage\resources\views/cashiers/settings.blade.php ENDPATH**/ ?>