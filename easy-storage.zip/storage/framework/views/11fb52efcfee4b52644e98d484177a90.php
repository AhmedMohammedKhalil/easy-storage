
<form wire:submit.prevent='edit' class="row flex-column align-items-center">
    <div class="col-lg-6 col-md-12">
        <div class="form-row mb-3 col-md-12">
            <div class="from-group  col-md-12 ">
                <div class="input-group ">
                    <textarea name="content" class="form-control" wire:model.lazy='content' id="content" rows="6"
                        placeholder="ادخل المحتوى"></textarea>
                </div>
            </div>
            <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-row mb-3 col-md-12">
            <div class="from-group col-md-12 ">
                <div class="input-group">
                    <input type="file" name="image" class="form-control" wire:model='image' placeholder="إرفع الصورة">
                </div>
            </div>
            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>
        <div class="col-12 col-sm-12 Login-btn d-flex justify-content-center">
            <button class="btn btn-secondary">حفظ</button>
        </div>
    </div>
</form>
<?php /**PATH D:\xampp\htdocs\easy-storage\resources\views/livewire/admin/about/edit.blade.php ENDPATH**/ ?>