<?php $__env->startPush('header'); ?>
<?php echo $__env->make('layouts.header',['title'=>'إضافة صورة جديدة'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('section'); ?>
<section class="order-content">
    <div class="heading-title">
        <h2 class="text-center" style="font-weight:bold;margin-bottom:30px"> إضافة صورة جديدة  </h2>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.gallary.add')->html();
} elseif ($_instance->childHasBeenRendered('r3FBgts')) {
    $componentId = $_instance->getRenderedChildComponentId('r3FBgts');
    $componentTag = $_instance->getRenderedChildComponentTagName('r3FBgts');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('r3FBgts');
} else {
    $response = \Livewire\Livewire::mount('admin.gallary.add');
    $html = $response->html();
    $_instance->logRenderedChild('r3FBgts', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\easy-storage\resources\views/admins/gallaries/create.blade.php ENDPATH**/ ?>