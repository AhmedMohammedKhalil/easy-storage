<?php $__env->startPush('header'); ?>
<?php echo $__env->make('layouts.header',['title'=>'لوحة التحكم'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('section'); ?>
<section class="pro-content bounse" style="padding-top: 0">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="pro-heading-title">
                    <h2 class="text-body text-center text-font">لوحة التحكم</h2>
                </div>
            </div>
        </div>
        <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 row-cols-xl-4 g-4">
            <div class="col">
                <a href="javascript:void(0)" class=" ">
                    <div class="box-spaeial text-center bounce_button">
                        <img src="<?php echo e(asset('assets/images/data/dashboard/users.png')); ?>" style="height: 100px" class="img-fluid" alt="...">
                        <h5 class="text-body my-3">
                            الكاشير
                        </h5>
                        <p><?php echo e($cashier_count); ?></p>
                    </div>
                </a>
            </div>

            <div class="col">
                <a href="javascript:void(0)" class=" ">
                    <div class="box-spaeial text-center bounce_button">
                        <img src="<?php echo e(asset('assets/images/data/dashboard/categories.png')); ?>" style="height: 100px" class="img-fluid" alt="...">
                        <h5 class="text-body my-3">
                            انواع المنتجات
                        </h5>
                        <p><?php echo e($category_count); ?></p>
                    </div>
                </a>
            </div>

            <div class="col">
                <a href="javascript:void(0)" class=" ">
                    <div class="box-spaeial text-center bounce_button">
                        <img src="<?php echo e(asset('assets/images/data/dashboard/products.png')); ?>" style="height: 100px" class="img-fluid" alt="...">
                        <h5 class="text-body my-3">
                            المنتجات
                        </h5>
                        <p><?php echo e($product_count); ?></p>
                    </div>
                </a>
            </div>

            <div class="col">
                <a href="javascript:void(0)" class=" ">
                    <div class="box-spaeial text-center bounce_button">
                        <img src="<?php echo e(asset('assets/images/data/dashboard/orders.png')); ?>" style="height: 100px" class="img-fluid" alt="...">
                        <h5 class="text-body my-3">
                            الأوردرات
                        </h5>
                        <p><?php echo e($order_count); ?></p>
                    </div>
                </a>
            </div>

            <div class="col">
                <a href="javascript:void(0)" class=" ">
                    <div class="box-spaeial text-center bounce_button">
                        <img src="<?php echo e(asset('assets/images/data/dashboard/messages.png')); ?>" style="height: 100px" class="img-fluid" alt="...">
                        <h5 class="text-body my-3">
                            الرسائل
                        </h5>
                        <p><?php echo e($message_count); ?></p>
                    </div>
                </a>
            </div>

            <div class="col">
                <a href="javascript:void(0)" class=" ">
                    <div class="box-spaeial text-center bounce_button">
                        <img src="<?php echo e(asset('assets/images/data/dashboard/sliders.webp')); ?>" style="height: 100px" class="img-fluid" alt="...">
                        <h5 class="text-body my-3">
                            السلايدرز
                        </h5>
                        <p><?php echo e($slider_count); ?></p>
                    </div>
                </a>
            </div>

            <div class="col">
                <a href="javascript:void(0)" class=" ">
                    <div class="box-spaeial text-center bounce_button">
                        <img src="<?php echo e(asset('assets/images/data/dashboard/galleries.svg')); ?>" style="height: 100px" class="img-fluid" alt="...">
                        <h5 class="text-body my-3">
                            معرض الصور
                        </h5>
                        <p><?php echo e($gallary_count); ?></p>
                    </div>
                </a>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\easy-storage\resources\views/admins/dashboard.blade.php ENDPATH**/ ?>