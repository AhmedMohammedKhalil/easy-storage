<div class="checkoutd-nav">
    <ul class="nav flex-column nav-pills mb-3" id="pills-tab">


        

        <li class="nav-item">
            <a class="nav-link <?php if(request()->routeIs('cashier.orders')): ?> active <?php endif; ?>"  href="<?php echo e(route('cashier.orders')); ?>" >جميع الطلبات</a>
        </li>

        <li class="nav-item">
            <a class="nav-link <?php if(request()->routeIs('cashier.profile')): ?> active <?php endif; ?>" href="<?php echo e(route('cashier.profile')); ?>">البروفايل</a>
        </li>

        <li class="nav-item">
            <a class="nav-link <?php if(request()->routeIs('cashier.changePassword')): ?> active <?php endif; ?>"  href="<?php echo e(route('cashier.changePassword')); ?>">تغيير كلمة السر</a>
        </li>

        <li class="nav-item">
            <a class="nav-link <?php if(request()->routeIs('cashier.settings')): ?> active <?php endif; ?>"  href="<?php echo e(route('cashier.settings')); ?>">الإعدادات</a>
        </li>

        <li class="nav-item">
            <a class="nav-link <?php if(request()->routeIs('cashier.logout')): ?> active <?php endif; ?>"  href="<?php echo e(route('cashier.logout')); ?>">خروج</a>
        </li>
    </ul>
</div>
<?php /**PATH D:\xampp\htdocs\easy-storage\resources\views/cashiers/menu.blade.php ENDPATH**/ ?>