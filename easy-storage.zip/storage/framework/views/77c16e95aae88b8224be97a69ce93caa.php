<?php $__env->startPush('css'); ?>
    <style>
        .accordian h2{
            margin-bottom: 0
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('header'); ?>
<?php echo $__env->make('layouts.header',['title'=>'إدارة جميع المسؤلين عن الكاشير'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('section'); ?>
<section class="order-content">
    <div class="heading-title">
        <h2 class="text-center" style="font-weight:bold;margin-bottom:30px"> جميع المسؤلين عن الكاشير </h2>
        <div class="col-12 col-sm-12 justify-content-center btn-cont">
            <div class="row">
                <a href="<?php echo e(route('admin.cashier.create')); ?>"
                    class="btn btn-secondary">إضافة كاشير جديد</a>
            </div>
        </div>
    </div>
    <?php $__currentLoopData = $cashiers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cashier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="accordian" style="margin-top: 20px">
        <table class="table top-table order-table">
            <tbody>
                <tr class="d-flex">
                    <td class="col-12 col-md-2 first-item">
                        <?php if($cashier->image): ?>
                            <img style="height:150px" class="img-fluid" src="<?php echo asset('assets/images/data/cashiers/'.$cashier->id.'/'.$cashier->image); ?>" alt="image">
                        <?php else: ?>
                            <img style="height:150px" class="img-fluid" src="<?php echo asset('assets/images/img_option/img-1.jpg'); ?>" alt="image">
                        <?php endif; ?>
                    </td>
                    <td class="col-12 col-md-2">
                       <h2><?php echo e($cashier->name); ?></h2>
                    </td>
                    <td class="col-12 col-md-3"><h2><?php echo e($cashier->email); ?></h2></td>
                    <td class="col-12 col-md-2">
                        <h2><?php echo e($cashier->phone); ?></h2>
                    </td>
                    <td class="col-12 col-md-3 justify-content-around">
                        <a href="<?php echo e(route('admin.cashier.edit',['id'=>$cashier->id])); ?>" style="padding:0 10px">
                            <i class="fas fa-pen-alt"></i>
                        </a>
                        <?php if(count($cashier->orders) == 0): ?>
                        <a href="<?php echo e(route('admin.cashier.delete',['id'=>$cashier->id])); ?>" style="padding:0 10px">
                            <i class="fas fa-trash-alt"></i>
                        </a>
                        <?php endif; ?>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php if(count($cashiers) == 0): ?>
        <div class="col-12 col-sm-12 justify-content-center" style="margin-top: 30px">
            <h3 class="text-center">لا يوجد كاشير</h3>
        </div>
    <?php endif; ?>

</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\easy-storage\resources\views/admins/cashiers/index.blade.php ENDPATH**/ ?>