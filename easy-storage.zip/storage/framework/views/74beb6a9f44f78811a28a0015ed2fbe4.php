<?php $__env->startPush('css'); ?>
    <style>
        .accordian h2{
            margin-bottom: 0
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('header'); ?>
<?php echo $__env->make('layouts.header',['title'=>' جميع الرسائل'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('section'); ?>
<section class="order-content">
    <div class="heading-title">
        <h2 class="text-center" style="font-weight:bold;margin-bottom:30px"> جميع الرسائل </h2>
    </div>
    <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="accordian" style="margin-top: 20px">
        <table class="table top-table order-table">
            <tbody>
                <tr class="d-flex">
                    <td class="col-12 col-md-3">
                       <h2><?php echo e($contact->name); ?></h2>
                    </td>
                    <td class="col-12 col-md-3"><h2><?php echo e($contact->email); ?></h2></td>
                    <td class="col-12 col-md-6">
                        <h2><?php echo nl2br( $contact->message ); ?></h2>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php if(count($contacts) == 0): ?>
        <div class="col-12 col-sm-12 justify-content-center" style="margin-top: 30px">
            <h3 class="text-center">لا يوجد رسائل</h3>
        </div>
    <?php endif; ?>

</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\easy-storage\resources\views/admins/contacts/index.blade.php ENDPATH**/ ?>