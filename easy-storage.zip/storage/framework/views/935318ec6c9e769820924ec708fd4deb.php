<?php $__env->startPush('header'); ?>
<?php echo $__env->make('layouts.header',['title'=>'تعديل من نحن'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('section'); ?>
<section class="order-content">
    <div class="heading-title">
        <h2 class="text-center" style="font-weight:bold;margin-bottom:30px"> تعديل من نحن </h2>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.about.edit',['about_id'=>$about_id])->html();
} elseif ($_instance->childHasBeenRendered('h8mDZLj')) {
    $componentId = $_instance->getRenderedChildComponentId('h8mDZLj');
    $componentTag = $_instance->getRenderedChildComponentTagName('h8mDZLj');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('h8mDZLj');
} else {
    $response = \Livewire\Livewire::mount('admin.about.edit',['about_id'=>$about_id]);
    $html = $response->html();
    $_instance->logRenderedChild('h8mDZLj', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\easy-storage\resources\views/admins/abouts/edit.blade.php ENDPATH**/ ?>