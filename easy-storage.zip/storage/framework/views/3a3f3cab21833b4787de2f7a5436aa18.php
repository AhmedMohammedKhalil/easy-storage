<?php $__env->startPush('css'); ?>
    <style>
        .cart-area h2{
            font-size: 20px !important;
            margin-bottom: 0;
            padding-top: 10px;
            text-align: center
        }

        .cart-area .right-table tbody th, .cart-area .right-table tbody td {
            padding: 10px 5px;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('header'); ?>
<?php echo $__env->make('layouts.header',['title'=>'الفاتورة الحالية'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('section'); ?>

<section class="">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h2 class="text-center" style="font-weight:bold;margin-bottom:30px">الفاتورة الحالية</h2>
            </div>
            <?php if(count($order->products) == 0): ?>
                <div class="col-12 col-sm-12 justify-content-center" style="margin-top: 30px">
                    <h3 class="text-center">لا يوجد منتجات</h3>
                </div>
            <?php else: ?>
            <div class="col-12 col-sm-12 cart-page-two cart-area">
                <div class="row">
                    <div class="col-12 col-lg-12">
                        <?php $__currentLoopData = $order->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="accordian" style="margin-top: 20px">
                            <table class="table top-table order-table">
                                <tbody>
                                    <tr class="d-flex">
                                        <td class="col-12 col-md-2 first-item justify-content-center">
                                            <?php if($product->image): ?>
                                                <img style="height:100px" class="img-fluid" src="<?php echo asset('assets/images/data/products/'.$product->id.'/'.$product->image); ?>" alt="image">
                                            <?php else: ?>
                                                <img style="height:100px" class="img-fluid" src="<?php echo asset('assets/images/img_option/img-1.jpg'); ?>" alt="image">
                                            <?php endif; ?>
                                        </td>
                                        <td class="col-12 col-md-2 justify-content-center">
                                            <h2><?php echo nl2br( $product->name ); ?></h2>
                                        </td>

                                        <td class="col-12 col-md-2 justify-content-center">
                                            <h2><?php echo nl2br( $product->price ); ?> دينار</h2>
                                            </td>

                                        <td class="col-12 col-md-2 justify-content-center">
                                            <h2><?php echo nl2br( $product->pivot->quantity ); ?></h2>
                                            </td>

                                        <td class="col-12 col-md-2 justify-content-center">
                                            <h2><?php echo nl2br( $product->pivot->total ); ?> دينار</h2>
                                            </td>
                                        <td class="col-12 col-md-2 justify-content-around">
                                            <a style="padding:0 10px"
                                                data-bs-toggle="collapse" href="#product-<?php echo e($product->id); ?>"
                                                role="button" aria-expanded="false">
                                                <i style="padding-top: 10px" class="fas fa-eye"></i>
                                            </a>
                                            <a href="<?php echo e(route('cashier.purchases-delete',['id'=> $product->pivot->id])); ?>" style="padding:0 10px">
                                                <i style="padding-top: 10px" class="fas fa-trash-alt"></i>
                                            </a>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="collapse" id="product-<?php echo e($product->id); ?>">
                                <div class="card card-body">
                                    <section class="orderdetail-content">
                                        <div class="row">
                                            <div class="col-12">
                                                <h2 style="font-weight:bold;text-align:center;margin-bottom:10px">بيانات المنتج</h2>
                                            </div>
                                            <div class="col-12 col-md-5">
                                                <table class="table order-id">
                                                    <tbody>
                                                        <tr class="d-flex align-items-center">
                                                            <td class="col-6 col-md-6">
                                                                <strong>اسم المنتج</strong>
                                                            </td>
                                                            <td class="col-6 col-md-6">
                                                                <p style="margin-bottom: 0"><?php echo e($product->name); ?></p>
                                                            </td>
                                                        </tr>
                                                        <tr class="d-flex align-items-center">
                                                            <td class="col-6 col-md-6">
                                                                <strong>كود المنتج</strong></td>
                                                            <td class="col-6 col-md-6">
                                                                <p style="margin-bottom: 0"><?php echo e($product->code); ?></p>
                                                            </td>
                                                        </tr>

                                                        <tr class="d-flex align-items-center">
                                                            <td class="col-6 col-md-6">
                                                                <strong>نوع المنتج</strong></td>
                                                            <td class="col-6 col-md-6">
                                                                <p style="margin-bottom: 0"><?php echo e($product->category->name); ?></p>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                            <div class="col-12 col-md-7">
                                                <table class="table order-id">
                                                    <tbody>
                                                        <tr class="d-flex align-items-center">
                                                            <td class="col-6 col-md-6">
                                                                <strong>سعر المنتج</strong>
                                                            </td>
                                                            <td class="col-6 col-md-6">
                                                                <p style="margin-bottom: 0"><?php echo e($product->price); ?> دينار كويتى</p>
                                                            </td>
                                                        </tr>
                                                        <tr class="d-flex align-items-center">
                                                            <td class="col-6 col-md-6">
                                                                <strong>الكمية المتاحة</strong></td>
                                                            <td class="col-6 col-md-6">
                                                                <p style="margin-bottom: 0"><?php echo e($product->quantity); ?></p>
                                                            </td>
                                                        </tr>

                                                        <tr class="d-flex align-items-center">
                                                            <td class="col-6 col-md-6">
                                                                <strong>الكمية المباعة</strong></td>
                                                            <td class="col-6 col-md-6">
                                                                <p style="margin-bottom: 0"><?php echo e($product->quantity_sold); ?></p>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>

                                            </div>
                                            <div class="col-12 col-sm-12">
                                                <div class="comments-area" style="background: white;padding:10px">
                                                    <h3 style="font-weight: bold">وصف المنتج</h3>
                                                    <p style="margin-bottom: 0"><?php echo nl2br($product->details); ?></p>
                                                </div>
                                            </div>
                                        </div>
                                    </section>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                    <div class="col-12 col-md-6">
                        <div class="summery">
                            <h3 class="text-center">اجمالى الفاتورة</h3>
                            <table class="table right-table">
                                <tbody>
                                    <tr>
                                        <th>الأجمالى</th>
                                        <td class="justify-content-end d-flex"><?php echo e($order->total_price); ?> دينار كويتى</td>

                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="col-12 col-xl-6 col-md-6">
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('cashier.complete-order')->html();
} elseif ($_instance->childHasBeenRendered('05vPa0m')) {
    $componentId = $_instance->getRenderedChildComponentId('05vPa0m');
    $componentTag = $_instance->getRenderedChildComponentTagName('05vPa0m');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('05vPa0m');
} else {
    $response = \Livewire\Livewire::mount('cashier.complete-order');
    $html = $response->html();
    $_instance->logRenderedChild('05vPa0m', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('cashiers.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\easy-storage\resources\views/cashiers/pruchases.blade.php ENDPATH**/ ?>