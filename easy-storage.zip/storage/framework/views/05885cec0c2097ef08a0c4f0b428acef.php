
<form wire:submit.prevent='edit' class="row flex-column align-items-center">
    <div class="col-lg-6 col-md-12">
        <div class="form-row mb-3">
            <div class="from-group col-md-12 ">
                <div class="input-group ">
                    <input type="text" name="c_number" wire:model.lazy='c_number' class="form-control form-text" placeholder="ادخل الرقم المدنى" >
                </div>
            </div>
            <?php $__errorArgs = ['c_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-row mb-3">
            <div class="from-group col-md-12 ">
                <div class="input-group ">
                    <input type="text" name="name" wire:model.lazy='name' placeholder="ادخل الإسم" class="form-control form-text">

                </div>
            </div>
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-row mb-3">
            <div class="from-group col-md-12 ">
                <div class="input-group">
                    <input type="email" name="email" wire:model.lazy='email' placeholder="ادخل البريد الألكترونى" class="form-control form-text" >
                </div>
            </div>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-row mb-3">
            <div class="from-group col-md-12 ">
                <div class="input-group">
                    <input type="text" name="phone" wire:model.lazy='phone' class="form-control form-text" placeholder="ادخل رقم الهاتف" >
                </div>
            </div>
            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>

        <div class="form-row mb-3">
            <div class="from-group col-md-12 ">
                <div class="input-group">
                    <input type="file" name="image" class="form-control" wire:model='image' placeholder="إرفع الصورة">
                </div>
            </div>
            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>



        <div class="col-12 col-sm-12 Login-btn d-flex justify-content-center">
            <button class="btn btn-secondary">حفظ</button>
        </div>

    </div>

</form>
<?php /**PATH D:\xampp\htdocs\easy-storage\resources\views/livewire/cashier/settings.blade.php ENDPATH**/ ?>