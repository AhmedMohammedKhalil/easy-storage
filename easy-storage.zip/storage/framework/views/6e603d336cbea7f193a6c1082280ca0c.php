<?php $__env->startPush('css'); ?>
    <style>
        .accordian h2{
            margin-bottom: 0
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('header'); ?>
<?php echo $__env->make('layouts.header',['title'=>'إدارة من نحن'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('section'); ?>
<section class="order-content">
    <h2 class="text-center" style="font-weight:bold;margin-bottom:30px"> إدارة من نحن </h2>

    <?php $__currentLoopData = $abouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $about): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="accordian" style="margin-top: 20px">
        <table class="table top-table order-table">
            <tbody>
                <tr class="d-flex">
                    <td class="col-12 col-md-3 first-item">
                        <?php if($about->image): ?>
                            <img style="height:100px" class="img-fluid" src="<?php echo asset('assets/images/data/abouts/'.$about->id.'/'.$about->image); ?>" alt="image">
                        <?php else: ?>
                            <img style="height:100px" class="img-fluid" src="<?php echo asset('assets/images/img_option/img-1.jpg'); ?>" alt="image">
                        <?php endif; ?>
                    </td>
                    <td class="col-12 col-md-6">
                       <h2><?php echo nl2br( $about->content ); ?></h2>
                    </td>
                    <td class="col-12 col-md-3 justify-content-around">
                        <a href="<?php echo e(route('admin.about.edit',['id'=>$about->id])); ?>" style="padding:0 10px">
                            <i class="fas fa-pen-alt"></i>
                        </a>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\easy-storage\resources\views/admins/abouts/index.blade.php ENDPATH**/ ?>