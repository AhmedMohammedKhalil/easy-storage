<form wire:submit.prevent='add'>
    <div class="pro-quantiy" <?php if($product->quantity == 0): ?> style="visibility: hidden" <?php endif; ?>>
        <div class="input-group-control2">
            <span class="input-group-btn">
                <button type="button" value="quantity<?php echo e($product->id); ?>"
                    class=" btn btn-secondary" wire:click='minus' data-type="minus"
                    data-field="">
                    <i class="fas fa-minus"></i>
                </button>
            </span>

            <input type="text" id="quantity<?php echo e($product->id); ?>" wire:model="quantity" name="quantity" class="form-control"
                maxlength="5" value="1" size="5" min="1" max="<?php echo e($product->quantity); ?>" style="width: 46px;text-align:center">

            <span class="input-group-btn">
                <button type="button" value="quantity<?php echo e($product->id); ?>"
                    class=" btn btn-secondary" wire:click='plus' data-type="plus"
                    data-field="">
                    <i class="fas fa-plus"></i>
                </button>
            </span>
        </div>
        <div class="icons">
            <button class="icon btn-secondary btn" title="اضافة الى مشترياتى" onclick="notificationCart();"
                tabindex="0">
                <i class="fas fa-shopping-bag" style="display: block !important"></i>
            </button>
        </div>
    </div>
    <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

</form>
<?php /**PATH D:\xampp\htdocs\easy-storage\resources\views/livewire/cashier/add-order.blade.php ENDPATH**/ ?>